CREATE TRIGGER before_book_insert
BEFORE INSERT ON Book
FOR EACH ROW
BEGIN
    SELECT RAISE(ABORT, 'Total copies and available copies must be non-negative')
    WHERE NEW.total_copies < 0 OR NEW.available_copies < 0;

    SELECT RAISE(ABORT, 'Available copies cannot exceed total copies')
    WHERE NEW.available_copies > NEW.total_copies;
END;

