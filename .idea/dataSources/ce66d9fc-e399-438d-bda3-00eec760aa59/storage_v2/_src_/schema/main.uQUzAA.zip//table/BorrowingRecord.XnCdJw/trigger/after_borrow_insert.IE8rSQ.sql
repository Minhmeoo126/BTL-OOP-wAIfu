CREATE TRIGGER after_borrow_insert
AFTER INSERT ON BorrowingRecord
FOR EACH ROW
BEGIN
    SELECT RAISE(ABORT, 'No copies available to borrow')
    WHERE (SELECT available_copies FROM Book WHERE id = NEW.book_id) < 0;

    UPDATE Book
    SET available_copies = available_copies - 1
    WHERE id = NEW.book_id;
END;

